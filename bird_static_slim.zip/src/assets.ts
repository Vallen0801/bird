export const birdImages: Record<string, string> = {
  sparrow: '/sparrow.webp',
  spotted_dove: '/spotted-dove.webp',
  pigeon: '/pigeon.webp',
  pheasant: '/golden-pheasant.webp',
  owl: '/northern-hawk-owl.webp',
  swallow: '/swallow.webp',
  ibis: '/crested-ibis.webp',
  hoopoe: '/dyson.webp',
};
