<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.webp" />
</div>

# 今天，先做一只鸟

This is a static Vite + React app. It does not require a backend server or API key.

## Run Locally

1. Install dependencies:

   ```bash
   npm install
   ```

2. Start the dev server:

   ```bash
   npm run dev
   ```

## Static Build

```bash
npm run build
```

Deploy the generated `dist/` directory to any static host, such as GitHub Pages, Netlify, Vercel static output, or Cloudflare Pages.

Recommended settings:

- Build command: `npm run build`
- Output directory: `dist`
